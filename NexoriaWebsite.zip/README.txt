Nexoria Website – GitHub Pages Version

Diese Website ist bereit zur Veröffentlichung über GitHub Pages.
- index.html = Hauptseite
- style.css = Design im Dark Mode
- NexoriaLauncher.exe/.rar = Deine App-Dateien (Platzhalter)

➡ Anleitung:
1. Füge deine echten Dateien ein
2. Push das Ganze nach GitHub
3. Aktiviere GitHub Pages in den Repo-Einstellungen

URL: https://david45bgfbsdfgb.github.io/Nexoria/
